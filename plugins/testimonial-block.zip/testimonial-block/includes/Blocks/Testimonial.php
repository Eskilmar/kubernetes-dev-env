<?php
namespace JMS_THEMES\Blocks;

defined( 'ABSPATH' ) || exit;
/**
 * Testimonial class.
 */
class Testimonial extends AbstractBlock {

    /**
     * Block name.
     *
     * @var string
     */
    protected $block_name = 'testimonial';
}
